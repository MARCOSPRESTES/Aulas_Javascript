console.log("Soma dos ímpares entre 11 e 21");
var soma = 0;
for (var i = 11; i <= 21; i+=2) {
  soma = soma + i; // soma += i;
}
console.log('A soma é ' + soma);