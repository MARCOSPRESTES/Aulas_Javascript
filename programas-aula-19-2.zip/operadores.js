var x = 10;
x -= 4; // x = x - 4;
x = x + 2; // x += 2;
var y = x ** 2;
console.log('x = ' + x + ', y = ' + y);