var x = 'Olá!';
console.log("Variáveis em JavaScript");
console.log("Texto: " + x + ", tipo de dado:" + typeof x);
x = 12 + 13;
console.log("Número inteiro: " + x +
  ", tipo de dado: " + typeof x);
x = 4.50 + 5.25;
console.log("Número real: " + x +
  ", tipo de dado: " + typeof x);
x = false;
console.log("Lógico: " + x + 
  ', tipo de dado: ' + typeof x);