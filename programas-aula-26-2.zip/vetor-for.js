var meses = new Array("Janeiro",
  "Fevereiro", "Março", "Abril", "Maio",
  "Junho", "Julho", "Agosto", "Setembro",
  "Outubro", "Novembro", "Dezembro");
console.log("Meses do ano:");
for (var mes in meses) {
  console.log(meses[mes]);
}