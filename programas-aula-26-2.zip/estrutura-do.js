console.log('Tabuada do 3... ');
var num = 1;
do {
  console.log('3 x ', num, ' = ', num * 3);
  num += 1;
} while (num <= 10);